Landing Page for Hello World project

