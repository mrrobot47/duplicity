"""hello world module"""


def hello(who):
    """function that greats"""
    return "hello " + who
